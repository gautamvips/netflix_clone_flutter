import 'package:flutter/material.dart';
import 'package:flutter_application_2/screen/bottomnav.dart';

void main() {
  runApp(const MaterialApp(
   // home: FirstPage(),
   //home: COUNTER()
   //home: HomePage(),
   home: NavBar(),
  ));
}