import 'package:flutter/material.dart';

class NETFLIXORIGINALS extends StatelessWidget {
  const NETFLIXORIGINALS({super.key});

  @override
  Widget build(BuildContext context) {
    return Column( //yha pr page/code break kra hai jisse ussjagha reusability krnege
      crossAxisAlignment: CrossAxisAlignment.start,              
      children: [
        Text("Netflix Originals",
        style: TextStyle(color: Colors.white,fontSize: 25,fontWeight: FontWeight.bold),),
        Container(
          color: Colors.black,
          width: double.infinity,
          height: 500,
          child: ListView(
            padding: const EdgeInsets.all(7),
            scrollDirection: Axis.horizontal,
            children:  [
             Container( 
                child:Image.asset("assets/witcher.jpg"),
              ),
              SizedBox(
                width: 10,
              ),
             Container(
                child: Image.asset("assets/sintel.jpg"),
              ),
              SizedBox(
                width: 10,
              ),
             Container(
                child: Image.asset("assets/umbrella_academy.jpg"),
              ),
              SizedBox(
                width: 10,
              ),
             Container(
                child: Image.asset("assets/carole.jpg"),
              ),
              SizedBox(
                width: 10,
              ),
             Container(
                child: Image.asset("assets/black_mirror.jpg"),
              ),
              SizedBox(
                width: 10,
              ),
             Container(
                child: Image.asset("assets/dogs.jpg"),
              ),
              SizedBox(
                width: 10,
              ),
              Container(
                child: Image.asset("assets/thirteen_reasons.jpg"),
              ),
              SizedBox(
                width: 10,
              ),
            ],
          ),
        )

      ],
    );
  }
}