import 'package:flutter/material.dart';

class PREVIEW extends StatelessWidget {
  const PREVIEW({super.key});

  @override
  Widget build(BuildContext context) {
    return  Column( //yha pr page/code break kra hai jisse ussjagha reusability krnege
      crossAxisAlignment: CrossAxisAlignment.start,              
      children: [
        Text("Previews",
        style: TextStyle(color: Colors.white,fontSize: 25,fontWeight: FontWeight.bold),),
        Container(
          color: Colors.black,
          width: double.infinity,
          height: 100,
          child: ListView(
            padding: const EdgeInsets.all(7),
            scrollDirection: Axis.horizontal,
            children: const [
              CircleAvatar( 
                radius: 50,
                backgroundImage: AssetImage("assets/dogs.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                  backgroundImage: AssetImage("assets/stranger_things.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                  backgroundImage: AssetImage("assets/sintel.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                  backgroundImage: AssetImage("assets/thirteen_reasons.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                  backgroundImage: AssetImage("assets/witcher.jpg"),
              ),
              CircleAvatar(
                radius: 50,
                  backgroundImage: AssetImage("assets/violet_evergarden.jpg"),
              ),CircleAvatar(
                radius: 50,
                  backgroundImage: AssetImage("assets/carole.jpg"),
              )
            ],
          ),
        )

      ],
    );
  }
}